#!/bin/bash

# 安装 pnpm
npm install -g pnpm

# 安装依赖
pnpm install

# 构建项目
pnpm build
